import { Component, OnInit } from '@angular/core';
import { SharedService } from 'src/app/shared.service';

@Component({
  selector: 'app-show-emp',
  templateUrl: './show-emp.component.html',
  styleUrls: ['./show-emp.component.css']
})
export class ShowEmpComponent implements OnInit {

  constructor(private service : SharedService) { }

  EmployeeList:any=[];

  ModalTitle : any;

  ActivateAddEditEmpComp:boolean=false;
  emp:any;

  ngOnInit(): void {
    this.refreshEmployeeList();
  }

  addClick(){
    this.emp = {
      firstName :"",
      lastName :"",
      email :"",
      phoneNumber :"",
      address :"",
      city :"",
      state :"",
      country :"",
    postalCode :"",
    }

    this.ModalTitle="Add Employee";
    this.ActivateAddEditEmpComp=true;
  }

  editClick(item:any){
    this.emp=item;
    this.ModalTitle="Edit Employee";
    this.ActivateAddEditEmpComp=true;
  }

  deleteClick(item:any){
if (confirm ('Are you sure?')){
  this.service.DeleteEmployee(item.id).subscribe(data =>{
    alert(data.toString());
    this.refreshEmployeeList();
  })
}
  }

  closeClick(){
    this.ActivateAddEditEmpComp=false;
    this.refreshEmployeeList();
  }

  refreshEmployeeList(){
    return this.service.getEmployeeList().subscribe(response =>{
      console.log(response);
      this.EmployeeList=response;
    });
  }
}
