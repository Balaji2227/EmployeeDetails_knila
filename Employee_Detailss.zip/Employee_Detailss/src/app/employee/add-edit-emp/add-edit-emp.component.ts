import { Component, OnInit,Input } from '@angular/core';
import { SharedService } from 'src/app/shared.service';

@Component({
  selector: 'app-add-edit-emp',
  templateUrl: './add-edit-emp.component.html',
  styleUrls: ['./add-edit-emp.component.css']
})
export class AddEditEmpComponent implements OnInit {

  @Input() emp:any;
  firstName : string = "";
    lastName : string = "";
    email : string = "";
    phoneNumber : string = "";
    address : string = "";
    city : string = "";
    state: string = "";
    country : string = "";
  postalCode : string = "";

  constructor(private service :SharedService) { }

  ngOnInit(): void {
    this.firstName =this.emp.firstName;
    this.lastName =this.emp.lastName
    this.email =this.emp.email;
    this.phoneNumber =this.emp.phoneNumber;
    this.address =this.emp.address;
    this.city =this.emp.city;
    this.state =this.emp.state;
    this.country =this.emp.country;
    this.postalCode =this.emp.postalCode;

  }
  addEmployee(){
 var val ={
  firstName:this.emp.firstName,
  lastName:this.emp.lastName,
  email:this.emp.email,
  phoneNumber:this.emp.phoneNumber,
  address:this.emp.address,
  city:this.emp.city,
  state:this.emp.state,
  country:this.emp.country,
  postalCode:this.emp.postalCode };
  this.service.addEmployee(val).subscribe(res =>{
    alert(res.toString());
  });
  }

  UpdateEmployee(){
    var val ={
      firstName:this.emp.firstName,
      lastName:this.emp.lastName,
      email:this.emp.email,
      phoneNumber:this.emp.phoneNumber,
      address:this.emp.address,
      city:this.emp.city,
      state:this.emp.state,
      country:this.emp.country,
      postalCode:this.emp.postalCode };
      this.service.UpdateEmployee(val).subscribe(res =>{
        alert(res.toString());
      });
  }

}
