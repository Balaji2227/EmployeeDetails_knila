﻿using ClientAPI.DataBase;
using ClientAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Runtime.InteropServices;

namespace ClientAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {

        private readonly EmployeeDbcontext EmployeeDbcontext;

        // Constructor via Dependancy injection.
        public EmployeeController(EmployeeDbcontext employeeDbcontext)
        {
            this.EmployeeDbcontext = employeeDbcontext;

        }

        [HttpGet]
        public async Task<IActionResult> GetAllEmployee()
        {
            var Employee = await EmployeeDbcontext.Employess.ToArrayAsync();

            return Ok(Employee);
        }


        [HttpPost]
        public async Task<IActionResult> CreateNewEmployee([FromBody]Employee emp)
        {
            emp.Id = new Guid();

            await EmployeeDbcontext.Employess.AddAsync(emp);
            await EmployeeDbcontext.SaveChangesAsync();

            return Ok(emp);
        }


        [HttpPut]
        [Route("{id:guid}")]
        public async Task<IActionResult> UpdateEmployee([FromRoute] Guid id, [FromBody] Employee emp)
        {
            

           var employee = await EmployeeDbcontext.Employess.FirstOrDefaultAsync(a => a.Id == id);
            
            if (employee == null)
            {
                employee.FirstName = emp.FirstName;
                employee.LastName = emp.LastName;
                employee.Email = emp.Email;
                employee.PhoneNumber = emp.PhoneNumber;
                employee.Address = emp.Address;
                employee.City = emp.City;
                employee.State = emp.State;
                employee.Country = emp.Country;
                employee.PostalCode = emp.PostalCode;

                await EmployeeDbcontext.SaveChangesAsync();

                return Ok(emp);
            }
            else
            {
                return NotFound("Employee Not Found");
            }
           
        }

        [HttpDelete]
        [Route("{id:guid}")]
        public async Task<IActionResult> DeleteEmployee([FromRoute] Guid id)
        {


            var employee = await EmployeeDbcontext.Employess.FirstOrDefaultAsync(a => a.Id == id);

            if (employee == null)
            {
                EmployeeDbcontext.Employess.Remove(employee);

                await EmployeeDbcontext.SaveChangesAsync();

                return Ok(employee);
            }
            else
            {
                return NotFound("Employee Not Found");
            }

        }
    }
}
