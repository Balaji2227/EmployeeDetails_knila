﻿using ClientAPI.Models;
using Microsoft.EntityFrameworkCore;

namespace ClientAPI.DataBase
{
    public class EmployeeDbcontext : DbContext
    {
        public EmployeeDbcontext(DbContextOptions options) : base(options)
        {
        }

        public DbSet<Employee> Employess { get; set; }
    }
}
